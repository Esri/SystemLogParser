﻿# ==============================================================================
# Updated:      2021-11-03
# Created by:   Justin Johns
# Filename:     Get-SLPReport.ps1
# Version:      0.1.1
# ==============================================================================

#Requires -Version 7.0 -Modules AWS.Tools.SecurityToken, AWS.Tools.S3

<# =============================================================================
.SYNOPSIS
    Invoke SLP to generate report from ELB logs
.DESCRIPTION
    Downloads all ELB logs from S3, decompresses gzip logs using 7zip, and
    invokes SLP to generate report.
.NOTES
    General notes
    This script was developed and tested on an EC2 instance with an instance
    profile granting it access to the specified S3 bucket. Credentials can be
    added if the system does not inherit credentials from an IAM Role.
    Written and developed for Mr. Aaron Lopez
============================================================================= #>

# SET VARIABLES
$bucketName = '<s3_bucket_name>'

# SET DIRECTORIES
$utils = "\\<share>\<path_to_slp_and_7zipa>"
$tempPath = $PSScriptRoot
$zipLogs = Join-Path -Path $tempPath -ChildPath 'compressed'
$unzLogs = Join-Path -Path $tempPath -ChildPath 'expanded'

# GET DATES
$date = (Get-Date).AddMonths(-1)
$firstDay = Get-Date -Date $date -Day 1 -Hour 0 -Minute 0 -Second 0
$lastDay = $firstDay.AddMonths(1).AddSeconds(-1)

# SET S3 PREFIXES
$elbPattern = 'AWSLogs/{0}/elasticloadbalancing/us-east-1' -f (Get-STSCallerIdentity).Account

#region DOWNLOAD LOGS ==========================================================
# UPDATE LOG
Write-Output -InputObject 'Starting download and decompression'

# SET PREFIX
$keyPrefix = '{0}/{1:yyyy}/{1:MM}/' -f $elbPattern, $date

# GET OBJECT COUNT
$elbLogs = Get-S3Object -BucketName $bucketName -KeyPrefix $keyPrefix
Write-Output -InputObject ('Log files found in date range: {0}' -f $elbLogs.Count)

# DOWNLOAD COMPRESSED DATA
Write-Output -InputObject 'Begin download'
$elbLogs | Foreach-Object -ThrottleLimit 8 -Parallel {
    $dst = Join-Path -Path $using:zipLogs -ChildPath (Split-Path -Path $_.Key -Leaf)
    Read-S3Object -BucketName $using:bucketName -S3Object $_ -File $dst | Out-Null
}
Write-Output -InputObject 'Download complete'
#endregion =====================================================================


#region COMBINE AND UNZIP LOGS =================================================
# REMOVE ANY 0 BYTE ZIPS
foreach ($zeroByte in (Get-ChildItem -Path $zipLogs | Where-Object Length -EQ 0)) {
    Remove-Item -Path $zeroByte.FullName -Confirm:$false
    Write-Output -InputObject ('Removed 0 Byte file: {0}' -f $zeroByte.Name)
}

# DECOMPRESS DATA
Write-Output -InputObject 'Being log decompression'
$7zParams = @{
    FilePath     = Join-Path -Path $utils -ChildPath "7z1900-extra\x64\7za.exe"
    ArgumentList = 'e', "-o""$unzLogs""", "$zipLogs\*.gz"
    Wait         = $true
    NoNewWindow  = $true
    PassThru     = $true
}
$proc = Start-Process @7zParams

# LOG 7ZIP STATUS
if ($proc.ExitCode -eq 0) { Write-Output -InputObject '7zip decompression of logs successful' }
else { Write-Output -InputObject ('ERROR: 7zip decompression exited with code: {0}' -f $proc.ExitCode) }

# REMOVE COMPRESSED LOGS
Remove-Item -Path $zipLogs -Recurse -Confirm:$false
Write-Output -InputObject 'Compressed ELB logs removed'
#endregion =====================================================================


#region INVOKE SLP AND REMOVE LOGS =============================================
# SET SLP PARAMETERS
$slpParams = @{
    FilePath     = Join-Path -Path $utils -ChildPath "SLP\Build 0.12.4.0\slp.exe"
    Wait         = $true
    NoNewWindow  = $true
    PassThru     = $true
    ArgumentList = @(
        '-f ELBFS'
        '-i {0}' -f $unzLogs
        # DATE FORMAT 'yyyy/MM/dd hh:mm:ss tt' OR 'yyyy/MM/dd HH:mm:ss'
        '-startstring {0:yyyy/MM/dd hh:mm:ss tt}' -f $firstDay
        '-endstring {0:yyyy/MM/dd hh:mm:ss tt}' -f $lastDay
        '-validate true'
        '-a optimized'
        '-d {0}' -f $tempPath # REPORT DESTINATION
        '-apploglevel DEBUG'
        '-o false' # SUPRESS REPORT OPENING
        '-n "SLP_ELBFSv2_{0}_{1:yyyy-MM}.xlsx"' -f $bucketName, $date
        #'-readthreads 4' # default is 5
    )
}

# LOG PARAMETER VALUES
Write-Output -InputObject ('SLP parameters: {0}' -f ($slpParams.ArgumentList -join "`n`t"))

# INVOKE SLP
Write-Output -InputObject 'Begin SLP process'
$proc = Start-Process @slpParams
Write-Output -InputObject 'SLP complete'

# REMOVE ELB LOGS
Remove-Item -Path $unzLogs -Recurse -Confirm:$false
Write-Output -InputObject 'Decompressed log files removed'

# VALIDATE EXECUTIONI
if ($proc.ExitCode -eq 0) { Write-Output -InputObject 'SLP report generated successfully' }
else { Write-Output -InputObject ('ERROR: SLP exited with code: {0}' -f $proc.ExitCode) }
#endregion =====================================================================