System Logs
Initial Release -- version 0.1.0.0
06/18/2015



Description: 
	System Logs is an ArcGIS for Server (10.1+) log query and analyzer tool.
 	When run, it connects to ArcGIS for Server as an administrator, retrieves 
	all logs from a time duration (specified as an input), analyzes the information
	then produces a spreadhseet version of the data that summarizes the service
	statistics.


Requirements:
	64bit version of Windows
	.NET 4.5 Full
	ArcGIS for Server 10.1+ (with logging set to Fine or higher)
	

How to Use:
	The initial version of System Logs is run via command-line only and takes 10 mandatory arguments

	The command-line syntax is as follows:
	SystemLogs.exe ArcGISServer_Hostname ArcGISServer_Port ArcGISServer_Administrative_User ArcGISServer_Administrative_Password outputdir_for_report hours_to_span_log_query minutes_to_span_log_query showservicecharts showoverviewcharts maxservices_to_summarize

	Example: SystemLogs.exe myserver.domain.com 6080 arcgis mypassword "C:\Users\User1\Documents" 4 0 true false -1

	ArcGISServer_Hostname			myserver.domain.com	(is the name of the machine running ArcGIS for Server 10.1+)
	ArcGISServer_Port 			6080	(is the port ArcGIS for Server 10.1+ is running on)
	ArcGISServer_Administrative_User 	arcgis	(the name of the primary site administrator or administrator of ArcGIS for Server 10.1+)
	ArcGISServer_Administrative_Password 	mypassword	(the name of the primary site administrator or administrator of ArcGIS for Server 10.1+)
	outputdir_for_report 			"C:\Users\User1\Documents"	(the path to a local folder where the report will be generated)
	hours_to_span_log_query			4	(number of hours from "now" to go back through the ArcGIS for Server logs)
	minutes_to_span_log_query 		0	(number of minutes from "now" to go back through the ArcGIS for Server logs; this is added to hours parameter)
	showservicecharts 			true	(specifies whether or not to render an ArcSOC elapsed time chart for each service)
	showoverviewcharts 			false	(specifies whether or not to render overview charts of the summarized service data)
	maxservices_to_summarize		-1	(specifies the maximum number of services to include in the analysis; set to -1 to include all services)

