System Log Parser
Version 0.6.3.0
Version Release: 02/17/2017


Description: 
	System Log Parser is an ArcGIS for Server (10.1+) log query and analyzer tool to
	help you quickly quantify the "GIS" in your deployment.
	When run, it connects to an ArcGIS for Server instance on port 6080 as a publisher
	(or an administrator), retrieves the logs from a time duration (specified as an input),
	analyzes the information then produces a spreadsheet version of the data that
	summarizes the service statistics.


-------------------------------
* CHANGELOG


Build 0.6.3.0 (Prerelease)
1. Corrected a small issue as well as expanded on the summarized log data that is uploaded to System Monitor for IIS traffic

Build 0.6.2.0 (Prerelease)
--------------
1. The example URL has been changed to "https://gisserver.domain.com:6443/arcgis" instead of "http://gisserver.domain.com:6080/arcgis". This was to let users know that System Log Parser supports HTTPS. Using HTTP to connect to an ArcGIS Server host on port 6080 will still work.
2. WMTSTile support has been added for IIS log uploads into System Monitor
3. Fixed a timing issue to help prevent the potential for log file read overlaps when uploading data into System Monitor

Build 0.6.1.3 (Prerelease)
--------------
1. When setting up System Log Parser as a System Monitor Task, the "Test" operation would incorrectly fail with "System.InvalidOperationException: Sequence contains no elements" if there were no IIS or ArcGIS server entries found for the default time frames.
   This output has now been corrected to return the appropriate JSON body.

Build 0.6.1.2 (Prerelease)
--------------
1. The default log verbosity setting in the Preferences.xml file has been changed from 'Warn' to 'Off'

Build 0.6.1.1 (Prerelease)
--------------
1. Fixed an issue where the report could not be created and would return the message "The given path's format is not supported" due to an illegal character
2. Fixed an issue in the ErrorsOnly Analysis Type report where some messages would still get truncated if they were longer than 150 characters

Build 0.6.1.0 (Prerelease)
--------------
1. Added enhancements for the integration of System Log Parser to System Monitor for both IIS and ArcGIS payloads
2. Added a new command line version of System Log Parser called slp.exe that optimizes System Log Parser to System Monitor communication. The existing command line features of "System Logs.exe" remain for backward compatibility.
3. Added ability to temporally show errors (errors with respect to time) with the ErrorsOnly Analysis Type report. Open the Preferences.xml file and set the <IsListErrorsTemporally>false</IsListErrorsTemporally> configuration to true. Restart System Log Parser.
4. Fix errors messages longer than 150 characters from being truncated in the ErrorsOnly Analysis Type report
5. Upgraded the internal EPPlus spreadsheet library to version 4.1 in order to increase the speed of creating large tables (errors/elapsed time tables)
6. Updated/simplified the command line help
7. The SystemMonitorConfiguration section in the Preferences file is a now deprecated feature and will no longer be supported with future releases of System Log Parser since newer installations of System Monitor (v3.0+) handle the passing in of this information automatically
8. Added a "busy cursor" for ArcGIS Server and Web queries for improved application feedback

Build 0.6.0.0 (Prerelease)
--------------
1. Removed Log Level from GUI. This setting had no functionality impact
2. Removed Warnings and Error worksheet from Complete report in order to improve speed
3. Warnings and Error worksheet is now its own report. This report is created when the new Analyst Type called 'ErrorsOnly' is selected
4. Redesigned Warnings and Error report to be faster, more detailed and more accurate
5. Redesigned the individual service worksheets in the Complete report into one comprehensive worksheet called "All Service Elapsed Times" which has a table containing all ArcSOC elapsed times. Users can then filter for specific service and just create the chart(s) they need. This can help reduce the Excel generation time and keeps the file size down of the report.
6. The <IsChartThroughput> option in the Preferences.xml file is now obsolete due to the table in the "All Service Elapsed Times" worksheet
7. Removed 'WithOverviewCharts' from the Analysis Type list. For backwards compatibility in command-line scripts, selecting this as an Analysis Type will default to 'Complete'.
8. Fixed incorrect exit code when uploading to System Monitor when an error was encountered
9. Improved verbosity (log and screen) if System Log Parser encounters any http errors
10. System Log Parser now treats most of the supporting http calls (which help provide additional but not critical information in the report) as non-fatal. Prior builds would stop if an error was encountered.
11. Fixed issue where some supporting http calls would not honor the timeout settings of the System Log Parser Preferences.xml file
12. Added ServerURL to the Preferences.xml file. For convenience, this can be "preset" to one specific, frequently used URL
13. Fixed issues that can crash System Log Parser when some command line options were specified but their input values omitted
14. Increased display time of the command line Help window before auto closing
15. SLP IIS to SM improvements such as immediate console feedback (used internally by System Monitor) and individual IIS request uploads
16. Fixed issue where SLP now no longer examines each service for the EnhancedSiteReport feature if SystemMonitor is selected as the ReportType. This helps speed up the SystemMonitor upload execution.
17. Added the "Requests over Time" worksheet to the 'Complete' Analysis Type which charts the requests as they occurred over either 24hrs or 1week (depending on the given timeframe)
18. Fixed an issue where the IsEnhancedSiteReport routine would honor the cancellation of a report generation
19. In the report, the ArcGIS Server Build number was added along with the listing of the ArcGIS Server Version number
20. Various internal code cleanup/optimizations

Build 0.5.1.1 (Prerelease)
--------------
1. Fixed an issue with the -o flag which under certain conditions would not honor the value passed in and would open up the report even if the user passed in the command line argument of "-o false"

Build 0.5.1.0 (Prerelease)
--------------
1. Fixed issue with the new IsEnhancedSiteReport feature (e.g. the Site Service Details worksheet) where the report would not generate if this process encountered a service type of WMServer, GlobeServer or FeatureServer. IsEnhancedSiteReport property is now set to true in Preferences file for new installations...a simple workaround for this issue was to just set the IsEnhancedSiteReport property to false and restart System Log Parser.
2. Fixed issue attempting to open the License Agreement (the E204_2014-06.docx file) from the About System Log Parser window
3. Added the MaxRecordCount listing to the Site Service Details worksheet for services that support this property

Build 0.5.0.0 (Prerelease)
--------------
1. System Log Parser is now Prerelease! Refer to the license page during installation or the E204_2014-06.docx file post-installation.
2. Added an enchancement to the Web (IIS) report to list counts for HTTP 2XX - HTTP 5xx requests
3. Fixed Web report labeling to not recommend checking ArcGIS Server if no log entries were found in IIS

Build 0.4.3.0
--------------
1. The IsEnhancedSiteReport option is now set to true for newly created Preference files. The IsEnhancedSiteReport performs additional queries against ArcGIS Server (not against the logs) in order to determine several specific service configuration settings. This information is also displayed in the report.
2. Full support for the ltag parameter when parsing a Web log and sending it to System Monitor. The ltag parameter is "log tag" option which helps System Monitor internally with the grouping the specific log data.

Build 0.4.2.1
--------------
1. Adjusted the column header comments and arraingment for the Web (IIS) report
2. Fixed small bug in the ArcGIS Server log report where Identify requests would show up as two different items if a Complete or WithOverviewCharts Analysis Type report was selected
3. Fixed issue where the Web (IIS) report would always count the requests in the logs even if they were not a status code of 200 or 300. 
   W3C field of Protocol Status (sc-status) is not required but highly recommended to include as it improves this accuracy in the report.
   With this version, the following are required in the IIS log in order to be parsed by System Log Parser:
		i.    Date (date)
		ii.   Time (time)
		iii.  Client IP Address (c-ip)
		iv.   User Name (cs-username)
		v.    Server IP Address (s-ip)
		vi.   URI Stem (cs-uri-stem)
		vii.  Time Taken (time-taken)
   The following fields are recommended to also be included in the IIS log:
		i.    Protocol Status (sc-status)
4. Improved the warning message clarity in text report if the ArcGIS Server logs did not contain any service requests for the given time duration
5. Updated the System Log Parser Help

Build 0.4.2.0
--------------
1. Added new feature to auto-detect the IIS log column availability matchup...no need to select the exact 15 specific set of fields in the W3C format. 
	* However, System Log Parser will require that at least the following fields are available in the IIS log:
		i.    Date (date)
		ii.   Time (time)
		iii.  Client IP Address (c-ip)
		iv.   User Name (cs-username)
		v.    Server IP Address (s-ip)
		vi.   URI Stem (cs-uri-stem)
		vii.  Time Taken (time-taken)		
2. System Log Parser does not require that the "Use local time for file naming and rollover" option In the IIS Log File Rollover section be selected
3. Added Preference to group the map cache tiles requests in the Web log based on the Level of Detail...this can help shorten the Web (IIS) report
4. Improved the warning message clarity in Excel report if the ArcGIS Server logs did not contain any service requests for the given time duration
5. Filtered the warning/error worksheet in the Excel report to be more specific to just warnings and errors

Build 0.4.1.0
--------------
1. Fix axis labeling for several charts from the Analysis Type of WithOverviewCharts.
2. Added command line option to validate the ArcGIS Server logs or Web logs upload to Esri System Monitor 3.0. With this option specified the System Monitor Report Server URL is only validated...the log payload is not persisted (by design). 
3. Corrected a few minor bugs for the Web Logs payload sent to Esri System Monitor 3.0
4. If System Log Parser is run from the command line and encounters and error, the runtime will issue an Exit of 1 instead of 0 (which generally signifies that the operation completed successfully)

Build 0.4.0.0
--------------
1. System Log Parser now has the ability to parse web logs. Currently this is limited to IIS and has the following requirements
	a. The Log File is in the W3C format 
	b. Use local time for file naming and rollover is checked
	c. The Log File format is W3C and has the following fields selected:
		i.    Date (date)
		ii.   Time (time)
		iii.  Client IP Address (c-ip)
		iv.   User Name (cs-username)
		v.    Server IP Address (s-ip)
		vi.   Server Port (s-port)
		vii.  Method (cs-method)
		viii. URI Stem (cs-uri-stem)
		ix.   URI Query (cs-uri-query)
		x.    Protocol Status (sc-status)
		xi.   Protocol Substatus (sc-substatus)
		xii.  Win32 Status (sc-win32-status)
		xiii. Time Taken (time-taken)
		xiv.  User Agent (cs(User-Agent))
		xv.   Referer (cs(Referer))
2. The ArcGIS Server charts in the report (when used with the Analyst Type of WithOverviewCharts or Complete) have been reworded in the interest of simplification and clarity
3. Support for sending the output of the ArcGIS Server logs or Web logs to Esri System Monitor 3.0 (see System Monitor 3.0 Help for details)

Build 0.3.6.0
--------------
1. Set 'Simple' to the default Analysis Type
2. In order to improve on log query performance, the QueryFilter used in the Preferences is overridden if 'Simple' is used an only log items with a code of 100004 (e.g. ArcSOC elapsed times) are retrieved. This can greatly shorten the query time.
3. Removed 'WithServiceCharts' from the Analysis Type list. For backwards compatibility in command-line scripts, selecting this as an Analysis Type will default to 'Complete'.
4. Increased application logging to aide with troubleshooting. Set the AppLogLevel tag in the Preferences to Info to increase application log verbosity.
5. Added ArcGIS Server's LogLevel and FileAge to the report
6. Moved the 'Max' column of the ArcSOC Elapsed time tabular view to the right so it is displayed immediately after P99

Build 0.3.5.4
--------------
1. Added some initial support for application logging
2. Fixed issue where the throughput chart (if enabled) would not render correctly and the times would be off by hour
3. Fixed issue where clicking cancel during a log query would not stop the query
4. Added better handling of an invalid Preferences file or invalid markup in the Preferences file
5. Enabled chart throughput rendering (up to 1 day) if a Complete Analysis Type is selected. Prior versions needed this option to also be set in the Preferences.

Build 0.3.5.2
--------------
1. Altered the internal storage format of the elapsed time floating point numbers from the logs to better account for international deployments. This now helps put the presentation format of Service Summary table on the viewing Spreadsheet program which is better equipped to honor the client environment's locale settings.

Build 0.3.5.1
--------------
1. Increased the error verbosity within the GUI when attempting to parse the ArcGIS Server ArcSOC elapsed time entries within the logs

Build 0.3.5.0
--------------
1. Added support to optionally create and store encrypted username and password Credential Sets within System Log Parser. Credential Sets allow you to reference a username and password by a string name that you can create through the GUI. For increased security, the username and password are encrypted before being saved. Automative scripts can then just reference the Credential Set by name.
2. Added '103800' to the default query filter
3. Enhanced the "Warning and Error Message Statistics" and "Map Server Request Statistics" tables so they are more informative
4. Updated the Help to cover the two new authentication options (Windows Authentication and Credential Set Authentication)
5. Fixed a bug that might cause System Log Parser to crash when run from the command line for certain versions of Windows

Build 0.3.4.0
--------------
1. Added support to optionally use Windows Authentication to a Web Adaptor endpoint (as opposed to passing in a username and password to the 6080/6443 endpoint). This can aide deployments that do not want to store the username/password in automative scripts but does require the Web Adaptor and ArcGIS Server to be configured for Windows Authentication at the Web tier.
2. Added support to the GUI to auto create the specified Output Directory if it does not exist
3. Added support to the GUI to check the specified output directory for write permission by the current user before starting the log query
4. Increased the size of the command line window to make the (command line) help easier to read. The command line help can be seen when System Log Parser is passed the "-h" option (from the command line).
5. Fixed the command line defaults to better match the GUI defaults

Build 0.3.3.3
--------------
1. Simplified the System Log Parser Help. The ability to configure the optional System Log Parser repository storage feature for use as a System Monitor Extension is now performed through Esri Professional Services. If you are interested in this optional feature, please contact Esri Professional Services.

Build 0.3.3.2
--------------
1. Installation now includes template bat script referenced in Help documentation for easily sending log information to System Monitor as needed. 

Build 0.3.3.1 
--------------
1. Fixed condition where selecting the Analysis Type of Simple still performed the logic for the other types but just did not add them to the report. Selecting Simple now does not do any of the other logic which can (slightly) speed up the report generation and potential avoid warnings from the tool (if warnings happened to be encountered with the other analysis types).
2. Clarified some references of the System Log Parser tool by name in the documentation 

Build 0.3.3.0 
--------------
1. Fixed User Overview worksheet...User Count per Unique "Service Method Machine User" chart was plotting number of user occurrences, it now plots the "service method machine user" metric correctly
2. Separated Service chart from SMMU (Service Method Machine User) chart
3. Made Overview charts easier to read and added verbal descriptions
4. Enhanced the "User Count per 'Service Method Machine User'" chart so its more informative
5. Added Count Percentages and Sum Percentages to the Service Summary table. These new columns let analyst quickly see which items are being requested the most as well as taking the most ArcSOC CPU.
6. Add a Preferences option to plot throughput (requests/sec) along with ArcSOC Elapsed Time if an Analysis Type of "Complete" was selected and the log query time period is 2 hours or less.
7. Fixed condition where date time data going into a System Monitor could be off 20 minutes with respect to the local time.
8. Fixed case where the Request Statistics worksheet could encounter problems attempting to parse the map scales
9. Added more support (detailed documentation) for sending captured ArcGIS Server log data to a System Monitor repository
10. Increased the "Log Messages per Query Page" default setting from 1000 to 9999 in order to help increase the performance of heavy log queries. Instead of using many smaller queries to generate a report System Log Parser now uses fewer, larger queries.

Build 0.3.2.0 
--------------
1. Added some support to send captured ArcGIS Server log data to a System Monitor repository
2. Fixed datetime representation of log data such that when viewed in System Monitor it is in the timezone of the machine running System Log Parser 
3. Added '0' and '8000' to the default query filter

Build 0.3.1.0 
--------------
1. Added a human readable DateTime column to the individual service charts that's dynamically formatted based on the given timespan and specifically used for making the charts easier to read
2. Added an additional Statistics page in the report called Request Statistics that lists information on the top 3 most requested map sizes and map scales. Note: currently, this only reports on REST export map and WMS requests.
3. Allowed System Log Parser Installer to automatically upgrade itself over an older version
4. Added '80014' to the default query filter
5. Fixed sizing on Back To Service Summary link

Build 0.3.0.0 
--------------
1. Added log error analysis which displays grouped error messages and a numeric count of their occurrence
2. Added the Machine Overview chart which breaks down the activity of serviced requests by machine (and cluster)
3. Added support for a Preferences file
	a) Added the option to specify a default value (in seconds) for the request timeout. This had a fixed value of 100 seconds which was encountered for some environments and caused the log query to stop prematurely.
	b) Added the option to specify a default value (in minutes) for the token expiration. The default ArcGIS Server value was encountered for some environments and could also cause the log query to stop prematurely.
	c) Added the option to specify the default column to sort by in the main Service table (e.g. on the Service Summary worksheet)
	d) Added the option to customize a specific list of ArcGIS Server codes to search when querying the logs
	e) Note: There are additional options in the Preferences file, but these other settings are currently unsupported
4. Changed default Analysis Type to WithOverviewChart to improve the generation speed of default report
5. Fixed an issue where "Add/Remove Programs" in Windows would show the incorrect installed version of System Log Parser
6. Corrected Starttime initialization value. Previous version based Starttime on "now", but it should be based on "now - the specified Endtime".
7. Added an "About System Log Parser" button (the blue exclamation point) on the graphical user interface to easily find the current version of the program

Build 0.2.4.0 
--------------
1. In the interest of improved scalability and stability, the individual service chart worksheet naming convention was changed to use a GUID instead of the "partial service name" and "occurance number". 
2. Added ArcGIS Server Version to one of the informational items stored at the top of report
3. Added the option of a text file to the list of report outputs
4. Increased the maximum number of allowable service items to report on
5. Added an additional hyperlink pointing back to the Service Summary above the chart of each individual service worksheet 

Build 0.2.3.0 
--------------
1. Fixed issue where System Log Parser could not parse certain log query results from deployments of where the locale of ArcGIS Server was not set to 'US'.
2. Added option to adjust the Log Messages per Query Page.
3. Added weighted average column at the end of the Service/Source summary which calculates the weighted average of the average ArcSOC processing time.
4. Renamed some of the connection and log query statistics section headers (e.g. Average Log Inquiry Time Total Inquiry Time), so these items are less likely to be confused information pertaining to the Service/Source summary items (e.g. Count, Avg, Stdev, etc...).
5. Split the Overview worksheet into two parts for easier viewing: Services Overview and Users Overview.
6. Renamed and clarified the chart titles for the Services Overview and Users Overview charts.
7. Added the 'Request Count per "Service"' chart to the Services Overview page which lists the most popular service based on all the Methods that users requested. Alternatively, the 'Request Count per "Service Method Machine User"' chart lists the most popular service based on the most hits to each Service-Method-Machine-User item.
8. Increased the verbosity of the error message if System Log Parser was not able to deserialize the ArcGIS Server log contents.

Build 0.2.2.0 
--------------
Initial Public Release